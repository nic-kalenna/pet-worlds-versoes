# Como testar a etapa 1 (Teste do Pet Worlds)

O Teste do Pet Worlds é um programa pequeno que confere se a fala, o som 3D e a tela desligada funcionam nos seus aparelhos. Não é o jogo ainda.

São três arquivos:

| Aparelho | Arquivo |
|---|---|
| Windows 11 | `TesteDoPetWorlds-0.1.1-etapa1-windows.zip` |
| Linux (WSL) | `TesteDoPetWorlds-0.1.1-etapa1-linux.zip` |
| Galaxy A30 | `TesteDoPetWorlds-0.1.1-etapa1-android.apk` |

## Instalar e abrir

### Windows
1. Descompacte o `.zip` numa pasta qualquer (por exemplo, `C:\programas\jogos\TesteDoPetWorlds`).
2. Abra `TesteDoPetWorlds.exe`.
3. Se aparecer "O Windows protegeu o computador", escolha "Mais informações" e depois "Executar assim mesmo". Isso acontece porque o programa ainda não tem assinatura digital.
4. A janela abre preta: os gráficos começam desligados, de propósito. Tudo é falado.

Teste uma vez com o **NVDA ligado** e outra com o **NVDA desligado**. Sem o NVDA, o programa fala sozinho pela voz SAPI.

### Linux pelo WSL
No Ubuntu do WSL, cole uma vez:

```
sudo apt update && sudo apt install -y speech-dispatcher espeak-ng pulseaudio-utils libpulse0 libgl1 libxcursor1 libxinerama1 libxrandr2 libxi6 libfontconfig1 unzip
```

Depois, troque `SEU_USUARIO` pelo seu usuário do Windows e cole:

```
cd ~ && unzip -o /mnt/c/Users/SEU_USUARIO/Downloads/TesteDoPetWorlds-0.1.1-etapa1-linux.zip && ./TesteDoPetWorlds/TesteDoPetWorlds.x86_64
```

No WSL o som passa por uma ponte até o Windows, então o atraso (teste 6) e o 3D (testes 3, 4 e 7) não são confiáveis lá. O que importa no WSL é: abre, fala pelo Speech Dispatcher e o som toca.

### Galaxy A30 (Android 11)
1. Baixe o `.apk` no celular e abra.
2. O Android vai pedir para permitir "instalar apps desconhecidos" para o app que abriu o arquivo. Permita uma vez.
3. Abra o "Teste do Pet Worlds". No Android a tela vem ligada, com botões grandes, e a fala é a voz do celular (TTS).

Teste com o **TalkBack desligado** (os gestos abaixo) e **ligado** (para ver se os botões são lidos).

## Teclas

| Tecla | O que faz |
|---|---|
| Setas para cima e para baixo | Escolher no menu; andar para a frente e para trás nas salas |
| Setas esquerda e direita | Andar para os lados nas salas |
| Shift + seta esquerda ou direita | Virar 45 graus |
| Shift + seta para baixo | Meia-volta |
| Alt + setas | Correr, nas salas |
| X | Ligar e desligar o modo de correr, nas salas |
| Enter | Confirmar |
| Esc | Voltar (no menu, duas vezes sai) |
| 1 a 9 | Abrir o teste direto, no menu |
| Control | Parar a fala |
| F1 | Ajuda da tela onde você está |
| F2 e F3 | Abaixar e aumentar o volume dos sons |
| F4 e F5 | Diminuir e aumentar a velocidade da voz do jogo |
| R | Repetir a última frase |
| F, C, H, Z, T | Nas salas: direção, posição, onde está o gato, chão, trocar Steam Audio e Godot |

## Gestos no celular (TalkBack desligado)

| Gesto | O que faz |
|---|---|
| Deslizar um dedo para cima ou para baixo | Escolher no menu; andar para a frente ou para trás |
| Deslizar um dedo para a esquerda ou direita | Andar para os lados |
| Toque duplo | Confirmar |
| Deslizar dois dedos para a esquerda ou direita | Virar 45 graus |
| Deslizar dois dedos para baixo | Meia-volta |
| Deslizar dois dedos para cima | Ajuda |
| Toque com dois dedos | Parar a fala |
| Toque com três dedos, ou o botão Voltar | Voltar |

Os botões da tela fazem as mesmas coisas, e são o caminho com o TalkBack ligado. Nas salas, o botão "Andar ou correr" liga e desliga a corrida.

## Os testes e o que conferir

| Teste | O que acontece | O que conferir |
|---|---|---|
| **1. Fala** | Itens que falam pelo leitor de tela, pela voz do jogo e pelos dois juntos; depois a lista de vozes. Cada voz fala o próprio nome; Enter escolhe. No Windows aparecem as vozes OneCore e as SAPI 5. A voz escolhida fica guardada. | Cada caminho fala? A voz escolhida é a que toca? A fala do jogo atropela o leitor de tela? |
| **2. Fila de fala** | Uma frase longa e, depois de 3 segundos, um aviso importante. | O aviso passa na frente sem embolar? A frase continua depois? Control para a fala? |
| **3. Som 3D** | Um gato mia parado no meio de uma sala vazia de 10 por 10 metros. Você começa ao sul, de frente para ele. | O miado vem do lado certo? Dá para saber se é na frente ou atrás? Fica mais alto quando você chega perto? (H diz onde o gato está, para conferir.) |
| **4. Gato passeando** | O gato dá uma volta em você a cada 20 segundos. Você só vira. | Dá para seguir o som de olhos fechados? |
| **5. Passos** | Metade da sala é madeira, metade é grama. | Cada passo faz o som do chão certo? Um passo a cada meio segundo é confortável? |
| **6. Atraso** | Espaço (ou tocar a tela) faz um clique direto. Enter faz o mesmo clique pelo Steam Audio. | O clique sai junto com o dedo? Há diferença entre os dois? |
| **7. Steam Audio ou Godot** | O gato do teste 3, e a tecla T troca entre o Steam Audio e o áudio do Godot. | Qual soa melhor no fone? E no alto-falante? |
| **8. Tela desligada** | Enter liga e desliga os gráficos. A cada 5 segundos o programa mede o processador. C fala a medida. | O uso cai bastante com a tela desligada? No celular, esquenta? |
| **9. Relatório** | Salva um arquivo de texto com o sistema, as vozes, as medidas e os erros, e copia o texto. | Cole o texto no chat do projeto. |

O relatório fica na pasta do programa (Windows e Linux) com o nome `relatorio-etapa-1.txt`. No celular, o texto fica copiado: é só colar no chat.

**Dica:** faça o teste 9 por último, depois dos outros, porque ele junta o que aconteceu em todos.

Para anotar o que achou de cada teste, use o `docs/resultado-etapa-1.md`, ou simplesmente conte no chat.
