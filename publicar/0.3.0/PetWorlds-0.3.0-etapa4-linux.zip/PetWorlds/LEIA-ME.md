# Como testar o Pet Worlds (versão 0.3.0, etapa 4)

| Aparelho | Arquivo |
|---|---|
| Windows 11 | `PetWorlds-0.3.0-etapa4-windows.zip` |
| Linux (WSL) | `PetWorlds-0.3.0-etapa4-linux.zip` |
| Galaxy A30 | `PetWorlds-0.3.0-etapa4-android.apk` |

## Instalar e abrir

- **Windows**: descompacte o `.zip` e abra `PetWorlds.exe`. Se aparecer "O Windows protegeu o computador", escolha "Mais informações" e "Executar assim mesmo". A janela abre preta: os gráficos começam desligados, e tudo é falado.
- **Linux (WSL)**: como na etapa 1, troque `SEU_USUARIO` pelo seu usuário do Windows:
  ```
  cd ~ && unzip -o /mnt/c/Users/SEU_USUARIO/Downloads/PetWorlds-0.3.0-etapa4-linux.zip && ./PetWorlds/PetWorlds.x86_64
  ```
- **Android**: abra o `.apk`. Ele substitui o "Teste do Pet Worlds" da etapa 1, que agora se chama "Pet Worlds".

O jogo é **portátil**: contas, opções e teclas ficam na pasta `dados`, dentro da pasta do jogo. Para levar para outro computador, basta copiar a pasta inteira. Por isso, não coloque o jogo em `C:\Arquivos de Programas`, onde ele não pode gravar.

## O que testar

1. **Menu inicial**: setas para cima e para baixo, Enter, Home e End, e Esc duas vezes para sair.
2. **Criar conta**: digite um nome e aperte Enter. Experimente Backspace, as setas para cima e para baixo (leem o nome), um nome vazio e um nome repetido. No celular, use a caixa de texto e o botão "Pronto".
3. **Jogar com conta**: escolha a conta, depois Jogar, depois **Andar pela casa de teste** (a etapa 4, veja abaixo). Experimente correr com V, ou com Alt e as setas.
4. **Mudar o nome** e **Apagar** a conta (o apagar pergunta antes e começa no "não").
5. **Opções**:
   - Idioma: troque para English e volte. Todo o menu muda de idioma.
   - Voz do jogo: as suas vozes SAPI 5 de 64 bits aparecem? A voz escolhida continua escolhida depois de fechar e abrir o jogo?
   - Velocidade, volume e leitor de tela, com as setas esquerda e direita.
   - Teclas: troque uma tecla, confira que ela funciona, troque para uma tecla que já é de outra ação (as duas trocam) e depois volte todas ao padrão.
6. **Sobre**: mostra a versão.
7. Os **testes técnicos da etapa 1** continuam em Opções, no fim da lista.

## A casa de teste (etapa 4)

Sala, cozinha e quintal, com portas abertas entre eles. Confira:

- O som do passo muda com o chão: madeira na sala, tapete no meio da sala, azulejo na cozinha, grama e terra no quintal.
- Você esbarra nos móveis e nos pets, e ouve o nome do que esbarrou.
- A gata Luna mia na sala e o cachorro Thor late no quintal, cada um do seu lugar.
- J e K passam pelas coisas, da mais perto para a mais longe; U e I trocam entre tudo, móveis, objetos e pets.
- Tab diz a distância e a direção; Home vira você para a coisa escolhida; B liga o bipe-farol, que acelera quando você chega perto. Dá para chegar até as tigelas da cozinha só pelo farol?
- Z diz o cômodo; Shift + Z descreve o lugar.
- Espaço perto de um pet faz carinho.

Detalhes e todas as teclas em `docs/etapa-4.md`.

## Teclas padrão

| Tecla | O que faz |
|---|---|
| Setas | Escolher no menu; andar no jogo |
| Setas esquerda e direita | Mudar um valor nas opções |
| Home e End | Primeiro e último item do menu |
| Shift + seta esquerda ou direita | Virar 45 graus |
| Shift + seta para baixo | Meia-volta |
| V | Ligar e desligar o modo de correr |
| Alt + setas | Correr |
| Enter | Confirmar; ação no jogo |
| Esc ou Backspace | Voltar |
| Control | Parar a fala |
| F1 | Ajuda da tela |
| F2 e F3 | Volume dos sons |
| F4 e F5 | Velocidade da voz do jogo |
| R | Repetir a última frase |

Todas podem ser mudadas em Opções, Teclas.

Conte no chat o que achou, ou anote em `docs/resultado-etapa-3.md`.
