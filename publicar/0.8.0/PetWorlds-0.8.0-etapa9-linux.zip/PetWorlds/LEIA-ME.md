# Como testar o Pet Worlds (versão 0.8.0, etapa 9)

| Aparelho | Arquivo |
|---|---|
| Windows 11 | `PetWorlds-0.8.0-etapa9-windows.zip` |
| Linux (WSL) | `PetWorlds-0.8.0-etapa9-linux.zip` |
| Galaxy A30 | `PetWorlds-0.8.0-etapa9-android.apk` |

## Instalar e abrir

- **Windows**: descompacte o `.zip` e abra `PetWorlds.exe`. Se aparecer "O Windows protegeu o computador", escolha "Mais informações" e "Executar assim mesmo". A janela abre preta: os gráficos começam desligados, e tudo é falado.
- **Linux (WSL)**: como na etapa 1, troque `SEU_USUARIO` pelo seu usuário do Windows:
  ```
  cd ~ && unzip -o /mnt/c/Users/SEU_USUARIO/Downloads/PetWorlds-0.8.0-etapa9-linux.zip && ./PetWorlds/PetWorlds.x86_64
  ```
- **Android**: abra o `.apk`. Ele substitui o "Teste do Pet Worlds" da etapa 1, que agora se chama "Pet Worlds".

O jogo é **portátil**: contas, opções e teclas ficam na pasta `dados`, dentro da pasta do jogo. Para levar para outro computador, basta copiar a pasta inteira. Por isso, não coloque o jogo em `C:\Arquivos de Programas`, onde ele não pode gravar.

## O que testar

1. **Menu inicial**: setas para cima e para baixo, Enter, Home e End, e Esc duas vezes para sair.
2. **Criar conta**: digite um nome e aperte Enter. Experimente Backspace, as setas para cima e para baixo (leem o nome), um nome vazio e um nome repetido. No celular, use a caixa de texto e o botão "Pronto".
3. **Jogar com conta**: escolha a conta, depois Jogar. O primeiro item, **Começar**, abre o jogo de verdade (veja "Novo na 0.4.0" abaixo). **Andar pela casa de teste** continua logo abaixo.
4. **Mudar o nome** e **Apagar** a conta (o apagar pergunta antes e começa no "não").
5. **Opções**:
   - Idioma: troque para English e volte. Todo o menu muda de idioma.
   - Voz do jogo: as suas vozes SAPI 5 de 64 bits aparecem? A voz escolhida continua escolhida depois de fechar e abrir o jogo?
   - Velocidade, volume e leitor de tela, com as setas esquerda e direita.
   - Teclas: troque uma tecla, confira que ela funciona, troque para uma tecla que já é de outra ação (as duas trocam) e depois volte todas ao padrão.
6. **Sobre**: mostra a versão.
7. Os **testes técnicos da etapa 1** continuam em Opções, no fim da lista.

## Novo na 0.8.0: minijogos e veterinária

- Na rua, use U e I até a categoria portas e J e K para achar o mercado e a padaria abertos (o nome diz "aberto" e o jogo). São os mais perto de casa. Ande contra a porta para entrar.
- Mercado: a máquina do caixa toca bipes; repita com as setas. Cada rodada põe um bipe a mais e dá mais moedas. Enter repete a sequência; Esc sai com as moedas.
- Padaria: um dos três fornos apita, à esquerda, à frente ou à direita; aperte a seta daquele lado antes de o pão queimar. Esc sai com as moedas.
- Leve o pet na coleira até a loja, vá ao consultório (atrás do balcão) e aperte Enter perto da Dra. Helena: a consulta custa 40 moedas.
- Em casa, Enter no telefone (na sala, perto da parede oeste) liga para ela vir examinar todos os pets por 70 moedas.
- Enter perto do telefone ou de outra coisa, com o sofá do lado, não senta mais: só senta quando o sofá é o mais perto.

Detalhes em `docs/etapa-9.md`.

## Novo na 0.7.0: carros e passeio

- Em casa, chegue perto do seu pet e aperte L: ele fica na coleira e anda logo atrás de você.
- Saia pela porta da rua com ele. Na rua, ouça os carros passando, cada um com o seu som, e o pet cheirando a calçada, puxando a coleira, latindo ou miando.
- Ande até uma esquina e fique virado para a faixa de pedestre: um tique lento quer dizer espere, e um tique rápido quer dizer pode atravessar. A fala avisa quando o sinal muda.
- Atravesse na faixa com o sinal aberto: os carros esperam. Fique no meio da rua fora da faixa: o carro para e buzina.
- Tente tirar a coleira na rua (L): não dá. Em casa dá.
- Salve no meio do passeio e abra de novo: o pet continua do seu lado, na coleira.

Detalhes em `docs/etapa-8.md`.

## Novo na 0.6.0: pets vivos

- Você anda mais rápido: o andar tem a velocidade do antigo correr. V e Alt com as setas não fazem mais nada.
- Adote um pet e vá para casa. Ele chega com um pouco de fome e sede, e as tigelas estão vazias. Logo ele vai até a tigela e reclama (mia ou late).
- Chegue perto da tigela de comida dele e aperte Enter: ela enche com uma porção de ração. Na de água, Enter enche de graça. J e K dizem se cada tigela está vazia, com um pouco ou cheia.
- Ouça o pet ir comer e beber sozinho.
- Enter perto do seu pet abre o menu dele: carinho, petisco, ração na mão, ver como está e as características. G continua fazendo carinho direto.
- N diz como está o seu pet mais perto: fome, sede, felicidade, confiança e saúde.
- Fique perto dele: a felicidade e a confiança sobem. Um pet tímido demora a confiar, e só segue você quando confia bastante.

Detalhes em `docs/etapa-7.md`.

## Novo na 0.5.0: moedas e compras

- Num jogo novo, M diz as suas moedas (entre 150 e 300).
- Adote um pet: a loja dá um kit (ração no inventário e um brinquedo em casa). X abre o inventário.
- Chegue perto do balcão ou da Marta e aperte Enter: compre ração, petisco, bola, mordedor ou tigelas. Tente comprar sem moedas suficientes.
- Em casa, ache a bola ou o mordedor novo (J e K) e as tigelas com o nome do seu pet.
- T diz a hora; Control + S salva.

Detalhes em `docs/etapa-6.md`.

## Novo na 0.4.1

- Passe pelas portas da loja e da casa: a direção não muda mais sozinha.
- A sua casa é a da 0.3.2. A Luna e o Thor estão na loja para adotar. Adote um deles e veja se o jeito dele aparece (a Luna é carinhosa e segue você; o Thor é brincalhão).
- Ouça os passos dos pets pela casa, os sons de fundo (casa, quintal, loja, rua e o mar perto da praia), o radar mais quieto e o bipe do B mais baixo.
- Segure a seta para andar e aperte outras teclas (J, Z, Tab): você continua andando.
- Ao abrir o jogo, nenhuma voz deve falar sozinha.
- Depois de sair, veja o relatório em `dados/relatorios`.

## Novo na 0.4.0: a loja, a adoção, a casa e a rua

1. Numa conta nova, escolha **Começar**. Você ouve a introdução e está dentro da Animais & Vida.
2. Os gatos ficam à sua esquerda (leste) e os cachorros à direita (oeste). Use U e I para a categoria pets, J e K para escolher um, Home para virar para ele e ande até ele (ou use o farol, B).
3. Perto dele, Enter: você ouve como ele é (sexo, raça, cor, porte, idade, jeito e voz). **Adotar** pede um nome. Experimente um nome vazio ou com vírgula (recusados).
4. Depois da adoção, saia pela porta da rua (atrás de você no começo, ao norte): ande contra ela. Você está na Rua das Gaivotas. Z diz a rua e o bairro.
5. A sua casa fica bem em frente, do outro lado da rua: ande para o norte até a porta dela (J e K mostram as portas) e ande contra a porta. O seu pet está na sala.
6. Tente entrar num outro prédio: ele diz que está fechado.
7. Saia do jogo (Esc) e entre de novo com **Continuar**: você volta para o mesmo lugar, com o seu pet.
8. Em Opções, **Saída de som**: troque para alto-falante (mono) e ande com o radar. Os sons dos lados mudam de tom. No celular, sem fone, isso ajuda?

Detalhes em `docs/etapa-5.md`.

## A casa de teste (etapa 4)

Sala, cozinha e quintal, com portas abertas entre eles. Confira:

- O som do passo muda com o chão: madeira na sala, tapete no meio da sala, azulejo na cozinha, grama e terra no quintal.
- Você esbarra nos móveis e nos pets, e ouve o nome do que esbarrou.
- A gata Luna mia na sala e o cachorro Thor late no quintal, cada um do seu lugar.
- J e K passam pelas coisas, da mais perto para a mais longe; U e I trocam entre tudo, móveis, objetos e pets.
- Tab diz a distância e a direção; Home vira você para a coisa escolhida; B liga o bipe-farol, que acelera quando você chega perto. Dá para chegar até as tigelas da cozinha só pelo farol?
- Z diz o cômodo; Shift + Z descreve o lugar.
- G perto de um pet faz carinho (a Luna ronrona).

Novo na 0.3.1:

- Espaço pula. A queda soa diferente em cada chão.
- Enter perto do sofá (ou do banco do quintal) senta; andar ou Enter de novo levanta.
- A Luna e o Thor andam sozinhos: passeiam, sobem no sofá, brincam com a bola, comem, bebem e às vezes vêm até você. Dá para seguir os passos deles?
- O radar toca enquanto você anda, como no A Hero's Call: à frente, o som da parede, porta, móvel ou pet que está chegando (até 2 metros), ou o de espaço livre; dos lados, avisa quando aparece uma abertura ou a parede volta. Parada, ele fica em silêncio. Um pet ou a bola que chega perto de você também toca. Q liga ou desliga o radar.

Novo na 0.3.2:

- Os pets andam mais devagar e esperam mais entre uma coisa e outra. A bola rola pelo quintal quando é empurrada (dá para ouvir ela indo embora), e o Thor vai buscar. A Luna tem um mordedor, que ela morde e às vezes leva na boca para outro canto.
- A cada 2 a 3 horas com o jogo aberto, cada pet vai às suas tigelas na cozinha, come e depois bebe. Cada um tem as suas.
- Em Opções, Voz, confira se as vozes do RHVoice Plus (Henrique, Letícia) aparecem agora. Se não, o relatório diz por quê.

Detalhes e todas as teclas em `docs/etapa-4.md`.

## Teclas padrão

| Tecla | O que faz |
|---|---|
| Setas | Escolher no menu; andar no jogo |
| Setas esquerda e direita | Mudar um valor nas opções |
| Home e End | Primeiro e último item do menu |
| Shift + seta esquerda ou direita | Virar 45 graus |
| Shift + seta para baixo | Meia-volta |
| Enter | Confirmar; no jogo, sentar, ver o que é, encher a tigela ou abrir o menu do seu pet |
| Espaço | Pular, no jogo |
| G | Carinho no pet mais perto |
| N | Como está o seu pet mais perto |
| L | Pôr ou tirar a coleira |
| Q | Ligar ou desligar o radar |
| Esc ou Backspace | Voltar |
| Control | Parar a fala |
| F1 | Ajuda da tela |
| F2 e F3 | Volume dos sons |
| F4 e F5 | Velocidade da voz do jogo |
| R | Repetir a última frase |

Todas podem ser mudadas em Opções, Teclas.

Conte no chat o que achou, ou anote em `docs/resultado-etapa-3.md`.
