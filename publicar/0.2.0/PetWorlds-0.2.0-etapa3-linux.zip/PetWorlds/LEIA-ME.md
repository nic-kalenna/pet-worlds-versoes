# Como testar o Pet Worlds (versão 0.2.0, etapa 3)

| Aparelho | Arquivo |
|---|---|
| Windows 11 | `PetWorlds-0.2.0-etapa3-windows.zip` |
| Linux (WSL) | `PetWorlds-0.2.0-etapa3-linux.zip` |
| Galaxy A30 | `PetWorlds-0.2.0-etapa3-android.apk` |

## Instalar e abrir

- **Windows**: descompacte o `.zip` e abra `PetWorlds.exe`. Se aparecer "O Windows protegeu o computador", escolha "Mais informações" e "Executar assim mesmo". A janela abre preta: os gráficos começam desligados, e tudo é falado.
- **Linux (WSL)**: como na etapa 1, troque `SEU_USUARIO` pelo seu usuário do Windows:
  ```
  cd ~ && unzip -o /mnt/c/Users/SEU_USUARIO/Downloads/PetWorlds-0.2.0-etapa3-linux.zip && ./PetWorlds/PetWorlds.x86_64
  ```
- **Android**: abra o `.apk`. Ele substitui o "Teste do Pet Worlds" da etapa 1, que agora se chama "Pet Worlds".

## O que testar

1. **Menu inicial**: setas para cima e para baixo, Enter, Home e End, e Esc duas vezes para sair.
2. **Criar conta**: digite um nome e aperte Enter. Experimente Backspace, as setas para cima e para baixo (leem o nome), um nome vazio e um nome repetido. No celular, use a caixa de texto e o botão "Pronto".
3. **Jogar com conta**: escolha a conta, depois Jogar. A sala de testes com o gato funciona como no teste 3. Experimente correr com V, ou com Alt e as setas.
4. **Mudar o nome** e **Apagar** a conta (o apagar pergunta antes e começa no "não").
5. **Opções**:
   - Idioma: troque para English e volte. Todo o menu muda de idioma.
   - Voz do jogo: as suas vozes SAPI 5 de 64 bits aparecem? A voz escolhida continua escolhida depois de fechar e abrir o jogo?
   - Velocidade, volume e leitor de tela, com as setas esquerda e direita.
   - Teclas: troque uma tecla, confira que ela funciona, troque para uma tecla que já é de outra ação (as duas trocam) e depois volte todas ao padrão.
6. **Sobre**: mostra a versão.
7. Os **testes técnicos da etapa 1** continuam em Opções, no fim da lista.

## Teclas padrão

| Tecla | O que faz |
|---|---|
| Setas | Escolher no menu; andar no jogo |
| Setas esquerda e direita | Mudar um valor nas opções |
| Home e End | Primeiro e último item do menu |
| Shift + seta esquerda ou direita | Virar 45 graus |
| Shift + seta para baixo | Meia-volta |
| V | Ligar e desligar o modo de correr |
| Alt + setas | Correr |
| Enter | Confirmar; ação no jogo |
| Esc ou Backspace | Voltar |
| Control | Parar a fala |
| F1 | Ajuda da tela |
| F2 e F3 | Volume dos sons |
| F4 e F5 | Velocidade da voz do jogo |
| R | Repetir a última frase |

Todas podem ser mudadas em Opções, Teclas.

Conte no chat o que achou, ou anote em `docs/resultado-etapa-3.md`.
